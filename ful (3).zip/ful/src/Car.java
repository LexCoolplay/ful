import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class Car {
    public final Action aStopPutGas;
    public final Action aStopTakeLeft;
    public final Action aStopTakeRight;
    public final Action aStopSteer;
    public final Action aStopPressClutch;
    public int x;
    public int y;
    public int angle = 0;
    public Color color;
    private boolean gasPressed;
    private boolean steering;
    private boolean takingLeft;
    private boolean takingRight;
    public int vel;
    public Action aPutGas;
    public Action aTakeLeft;
    public Action aTakeRight;
    public Action aSteer;
    public Action aPressClutch;
    public Action aRaiseTransmission;
    public Action aLowerTransmission;
    public BufferedImage Image;

    Car(int x, int y) {
        Random r = new Random();
        this.x = x;
        this.y = y;
        try {
            this.Image = ImageIO.read(new File("data/image" + angle + ".png"));
        }
        catch (IOException ie) {
            System.out.println("No such file");
        }

        this.aPutGas = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gas();
            }
        };
        this.aTakeLeft = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                takeLeft();
            }
        };
        this.aTakeRight = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                takeRight();
            }
        };this.aSteer = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                steer();
            }
        };
        this.aLowerTransmission = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        };
        this.aRaiseTransmission = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        };
        this.aPressClutch = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        };

        this.aStopPutGas = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopGas();
            }
        };
        this.aStopTakeLeft = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopTakeLeft();
            }
        };
        this.aStopTakeRight = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopTakeRight();
            }
        };this.aStopSteer = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopSteer();
            }
        };
        this.aStopPressClutch = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        };

        this.vel = 0;
        this.angle = 0;
        this.color = new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256));
    }

    private void stopGas() {
        gasPressed = false;
        // to do : transmission
    }

    private void stopSteer() {
        steering = false;
            }

    private void stopTakeLeft() {
        takingLeft = false;
            }

    private void stopTakeRight() {
        takingRight = false;
    }

    private void gas() {
        gasPressed = true;
        // to do : transmission
    }

    private void steer() {
        steering = true;
    }

    private void takeLeft() {
        takingLeft = true;
    }

    private void takeRight() {
        takingRight = true;
    }

    public void update() {
        if(gasPressed){
            if(vel >= 5)
                vel = 5;
            else
                vel += 2;
        }
        else{
            if(vel >= 3)
            vel -= 3;
            else{
                vel = 0;
            }
        }
        if(steering){
            if(vel >= 3)
                vel = -3;
            else
                vel = 0;
        }
        if(takingLeft){
            angle += 5;
        }
        if(takingRight){
            angle -= 5;
        }
        angle = angle < 0? 360+angle : angle;
        angle = angle % 360;
        try {
            this.Image = ImageIO.read(new File("data/image" + angle + ".png"));
        }
        catch (IOException ie) {
            System.out.println("No such file");
        }
        x += vel * Math.cos(Math.toRadians(angle+180));
        y -= vel * Math.sin(Math.toRadians(angle+180));
    }
}