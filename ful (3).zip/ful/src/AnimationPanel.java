import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;

public class AnimationPanel extends JPanel implements Runnable{

    private int x;
    private Camera camera = new Camera(1024, 1024, 0, 0);
    private int y;
    private boolean running;
    private Car car;
    private BufferedImage map;
    private int map_x = 0;
    private int map_y = 0;

    public AnimationPanel () {
        super(true);

        try{
            map = ImageIO.read(new File("data/map.jpg"));
        }catch (IOException e){
            System.out.println("No such image!");
        }



        x =  this.getWidth() / 2;
        y = this.getHeight() / 2;
        this.car = new Car(x,y);
        running = true;
        this.getInputMap().put(KeyStroke.getKeyStroke("W"), "putGas");
        this.getInputMap().put(KeyStroke.getKeyStroke("S"), "steer");
        this.getInputMap().put(KeyStroke.getKeyStroke("A"), "takeRight");
        this.getInputMap().put(KeyStroke.getKeyStroke("D"), "takeLeft");
        this.getInputMap().put(KeyStroke.getKeyStroke("SPACE"), "pressClutch");
        this.getInputMap().put(KeyStroke.getKeyStroke("UP"), "raiseTransmission");
        this.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "lowerTransmission");

        this.getInputMap().put(KeyStroke.getKeyStroke("released W"), "stopPutGas");
        this.getInputMap().put(KeyStroke.getKeyStroke("released S"), "stopSteer");
        this.getInputMap().put(KeyStroke.getKeyStroke("released A"), "stopTakeRight");
        this.getInputMap().put(KeyStroke.getKeyStroke("released D"), "stopTakeLeft");
        this.getInputMap().put(KeyStroke.getKeyStroke("released SPACE"), "stopPressClutch");


        this.getActionMap().put("putGas", car.aPutGas);
        this.getActionMap().put("steer", car.aSteer);
        this.getActionMap().put("takeRight", car.aTakeRight);
        this.getActionMap().put("takeLeft", car.aTakeLeft);
        this.getActionMap().put("pressClutch", car.aPressClutch);
        this.getActionMap().put("raiseTransmission", car.aRaiseTransmission);
        this.getActionMap().put("lowerTransmission", car.aLowerTransmission);

        this.getActionMap().put("stopPutGas", car.aStopPutGas);
        this.getActionMap().put("stopSteer", car.aStopSteer);
        this.getActionMap().put("stopTakeRight", car.aStopTakeRight);
        this.getActionMap().put("stopTakeLeft", car.aStopTakeLeft);
        this.getActionMap().put("stopPressClutch", car.aStopPressClutch);
        Thread t = new Thread(this);
        t.start();

    }



    @Override
    public void run() {
        double angle = 0;
        while (running) {
            car.update();
            camera.update(car.x, car.y, 1024, 1024);
            repaint();
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
        @Override
        public void paint(Graphics g){
        super.paint(g);
        g.setColor(Color.BLUE);

        ImageObserver observer = new ImageObserver() {
            @Override
            public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
                return false;
            }
        };


        map_x -= car.vel * Math.cos(Math.toRadians(car.angle+180));
        map_x = map_x < -this.map.getWidth()+this.getWidth() || car.x > this.getWidth()? -this.map.getWidth()+this.getWidth() : map_x;
        map_x = map_x > 0 || car.x < 0? 0 : map_x;

        map_y += car.vel * Math.sin(Math.toRadians(car.angle+180));
        map_y = map_y < -this.map.getHeight()+this.getHeight() || car.y > this.getWidth()? -this.map.getHeight()+this.getHeight() : map_y;
        map_y = map_y > 0 || car.y < 0? 0: map_y;

        car.x = map_x <= -this.map.getWidth()+this.getWidth() || map_x >= 0? car.x: car.x-Math.toIntExact(Math.round(car.vel * Math.cos(Math.toRadians(car.angle+180))));
        car.y = map_y <= -this.map.getHeight()+this.getHeight() || map_y >= 0? car.y: car.y+Math.toIntExact(Math.round(car.vel * Math.sin(Math.toRadians(car.angle+180))));

        g.drawImage(this.map, map_x, map_y, observer);
        System.out.print(map_x < -this.map.getWidth()+this.getWidth() || map_x > 0);
        g.drawImage(car.Image,car.x, car.y, observer);

    }
}
