import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args){
        JFrame window = new JFrame();
        window.setTitle("Animation test");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(800, 600);
        AnimationPanel ap = new AnimationPanel();
        window.setLayout(new BorderLayout());
                window.add(ap);
                window.setVisible(true);
    }
}
