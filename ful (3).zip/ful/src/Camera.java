public class Camera {
    private int width;
    private int height;
    private int winWidth = 800;
    private int winHeight = 600;
    public int x;
    public int y;
    Camera(int width, int height, int x, int y){
        this.width = width;
        this.height = height;
        this.x = x;
        this.y = y;
    }
    void update(int targetX, int targetY, int targetWidth, int targetHeight){
        int left = winWidth/2;
        int right = width - winWidth/2;
        int top = winHeight/2;
        int bottom = height - winHeight/2;

        x = left < targetX? left : targetX;
        if(x==left)
        x = right > targetX? right : targetX-right;

        y = top < targetY? top: targetY;
        if(y==top)
        y = bottom > targetY  ? bottom: targetY-bottom;
    }
}
